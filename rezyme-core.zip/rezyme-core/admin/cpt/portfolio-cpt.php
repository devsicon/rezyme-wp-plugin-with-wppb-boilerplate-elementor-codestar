<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed direct
/**
 * Register a custom post type called "portfolio".
 *
 * @see get_post_type_labels() for label keys.
 */


if (!function_exists('rezyme_portfolio')) {
    
function rezyme_portfolio() {
    $labels = array(
        'name'                  => _x( 'Portfolio', 'rezyme-core' ),
        'singular_name'         => _x( 'Portfolio', 'rezyme-core' ),
        'menu_name'             => _x( 'Portfolio', 'rezyme-core' ),
        'name_admin_bar'        => _x( 'Portfolio', 'rezyme-core' ),
        'add_new'               => __( 'Add New Portfolio', 'rezyme-core' ),
        'add_new_item'          => __( 'Add New Portfolio', 'rezyme-core' ),
        'new_item'              => __( 'New Portfolio', 'rezyme-core' ),
        'edit_item'             => __( 'Edit Portfolio', 'rezyme-core' ),
        'view_item'             => __( 'View Portfolio', 'rezyme-core' ),
        'all_items'             => __( 'All Portfolio', 'rezyme-core' ),
        'search_items'          => __( 'Search Portfolio', 'rezyme-core' ),
        'parent_item_colon'     => __( 'Parent Portfolio:', 'rezyme-core' ),
        'not_found'             => __( 'No Portfolio found.', 'rezyme-core' ),
        'not_found_in_trash'    => __( 'No Portfolio found in Trash.', 'rezyme-core' ),
        'featured_image'        => _x( 'Portfolio Featured Image',  'rezyme-core' ),
        'set_featured_image'    => _x( 'Set Portfolio Featured image', 'rezyme-core' ),
        'remove_featured_image' => _x( 'Remove image', 'rezyme-core' ),
        'use_featured_image'    => _x( 'Use as image', 'rezyme-core' ),
        'archives'              => _x( 'Portfolio archives', 'rezyme-core' ),
        'insert_into_item'      => _x( 'Insert into Portfolio', 'rezyme-core' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this Portfolio', 'rezyme-core' ),
        'filter_items_list'     => _x( 'Filter Portfolio list', 'rezyme-core' ),
        'items_list_navigation' => _x( 'Portfolio list navigation', 'rezyme-core' ),
        'items_list'            => _x( 'Portfolio list', 'rezyme-core' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'portfolio' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
        'show_in_rest'       => true,
    );
 
    register_post_type( 'portfolio', $args );
}
add_action( 'init', 'rezyme_portfolio' );

function rezyme_portfolio_category() {
    register_taxonomy( 'category', 'portfolio', array(
        'labels'            => array(
            'name'              => _x( 'Category', 'rezyme-core' ),
            'singular_name'     => _x( 'Category', 'rezyme-core' ),
            'search_items'      => __( 'Search Category', 'rezyme-core' ),
            'all_items'         => __( 'All Category', 'rezyme-core' ),
            'view_item'         => __( 'View Category', 'rezyme-core' ),
            'parent_item'       => __( 'Parent Category', 'rezyme-core' ),
            'parent_item_colon' => __( 'Parent Category:', 'rezyme-core' ),
            'edit_item'         => __( 'Edit Category', 'rezyme-core' ),
            'update_item'       => __( 'Update Category', 'rezyme-core' ),
            'add_new_item'      => __( 'Add New Category', 'rezyme-core' ),
            'new_item_name'     => __( 'New Category Name', 'rezyme-core' ),
            'not_found'         => __( 'No Category Found', 'rezyme-core' ),
            'back_to_items'     => __( 'Back to Category', 'rezyme-core' ),
            'menu_name'         => __( 'Category', 'rezyme-core' ),
        ),
        'hierarchical'      => true,
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'category', 'with_front' => false ),
        'show_in_rest'      => true,
    ) ); 
}
add_action( 'init', 'rezyme_portfolio_category' );


}


