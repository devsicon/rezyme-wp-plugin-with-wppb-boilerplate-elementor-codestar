<?php
/**
 * @author TeconceTheme
 * @since   1.0
 * @version 1.0
 */
 
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class pivoo_recipe_grid extends Widget_Base {

   public function get_name() {
      return 'pivoo_regular_recipe_grid';
   }

   public function get_title() {
      return __( 'Pivoo Recipe Regular Grid', 'pivoo' );
   }
public function get_categories() {
		return [ 'pivoo-ele-cat' ];
	}
   public function get_icon() { 
        return 'fab fa-product-hunt';
   }

   protected function _register_controls() {

      $this->add_control(
         'grid_recipe_post',
         [
            'label' => __( 'Pivoo Recipe Regular Grid', 'pivoo' ),
            'type' => Controls_Manager::SECTION,
         ]
      );
      
      $this->add_control(
			'widget_title',
			[
				'label' => __( 'Section Title', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Latest Recipe', 'pivoo' ),
				'placeholder' => __( 'Type your title here', 'pivoo' ),
				 'section' => 'grid_recipe_post',
			]
		);
		
		$this->add_control(
			'widget_sub_title',
			[
				'label' => __( 'Section Sub Title', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Latest Recipe', 'pivoo' ),
				'placeholder' => __( 'Type your sub title here', 'pivoo' ),
				 'section' => 'grid_recipe_post',
			]
		);
		
		  $this->add_control(
			'button_url',
			[
				'label' => __( 'Button URL', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '', 'pivoo' ),
				'placeholder' => __( 'Type your url here', 'pivoo' ),
				 'section' => 'grid_recipe_post',
			]
		);
      
       $this->add_control(
			'button_text',
			[
				'label' => __( 'Button Text', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '', 'pivoo' ),
				'placeholder' => __( 'Type your text here', 'pivoo' ),
				 'section' => 'grid_recipe_post',
			]
		);
		
    $this->add_control(
            'grid_layout',
            [
            'label'     => esc_html_x( 'Grid Style Layout', 'Admin Panel','pivoo' ),
            'description' => esc_html_x('Grid layout for the post"', 'pivoo' ),
            'type'      =>  Controls_Manager::SELECT,
            'default'    =>  "one",
            'section' => 'grid_recipe_post',
            "options"    => array(
            "one" => "Style One",
            "two" => "Style Two",
            "three" => "Style Three",
            "four" => "Style Four",
            ),
            ]
        
        );
        
         $this->add_control(
            'grid_column',
            [
            'label'     => esc_html_x( 'Grid Column', 'Admin Panel','pivoo' ),
            'description' => esc_html_x('Grid layout for the post"', 'pivoo' ),
            'type'      =>  Controls_Manager::SELECT,
            'default'    =>  "four",
            'section' => 'grid_recipe_post',
            "options"    => array(
            "one" => "One Column",
            "two" => "Two Column",
            "three" => "Three Column",
            "four" => "Four Column",
            "five" => "Five Column",
            "six" => "Six Column",
            ),
            ]
        
        );
      
      $this->add_control(
            'item_per_page',
            [
                'label'   => esc_html_x( 'Amount of item to display', 'Admin Panel', 'mayosis' ),
                'type'    => Controls_Manager::NUMBER,
                'default' =>  "4",
                'section' => 'grid_recipe_post',
            ]
        );
        
        $this->add_control(
            'order',
            [
                'label' => __( 'Order', 'mayosis' ),
                'type' => Controls_Manager::SELECT,
                'section' => 'grid_recipe_post',
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending'
                ],
                'default' => 'desc',

            ]
        );
        
        
        
        $this->add_control(
			'featured',
			[
				'label' => __( 'Featured Post', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'pivoo' ),
				'label_off' => __( 'No', 'pivoo' ),
				'section' => 'grid_recipe_post',
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
        
    $this->add_control(
      'pagination',
      array(
        'label'        => esc_html__( 'Show Pagination', 'pivoo' ),
        'type'         => Controls_Manager::SELECT,
        'default'      => 'yes',
        'section' => 'grid_recipe_post',
        'options'     => array(
          'yes'       => 'Yes',
          'no'        => 'No'
        ),
      )
    );
        $this->add_control(
      'category',
      array(
        'label'       => esc_html__( 'Select Categories', 'pivoo' ),
        'type'        => Controls_Manager::SELECT2,
        'multiple'    => true,
        'section' => 'grid_recipe_post',
        'options'     => array_flip(pivoo_elements_items( 'categories', array(
          'sort_order'  => 'ASC',
          'taxonomy'    => 'recipe-category',
          'hide_empty'  => false,
        ) )),
        'label_block' => true,
      )
    );
    
     $this->add_control(
      'categorynotin',
      array(
        'label'       => esc_html__( 'Exclude Categories', 'pivoo' ),
        'type'        => Controls_Manager::SELECT2,
        'multiple'    => true,
        'section' => 'grid_recipe_post',
        'options'     => array_flip(pivoo_elements_items( 'categories', array(
          'sort_order'  => 'ASC',
          'taxonomy'    => 'recipe-category',
          'hide_empty'  => false,
        ) )),
        'label_block' => true,
      )
    );
    
    
    $this->start_controls_section(
	'pagination_style',
	[
		'label' => __( 'Grid Style', 'pivoo' ),
		'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
	]
        );
    
    
        $this->add_control(
			'pagination_color',
			[
				'label' => __( 'Pagination text color', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#0D004D',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .pivoo-common-paginav a, {{WRAPPER}} pivoo-common-paginav span' => 'color: {{VALUE}}',
				],
			]
		);
		
		 $this->add_control(
			'pagination_active_color',
			[
				'label' => __( 'Pagination active text color', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ffffff',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .pivoo-common-paginav .current' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'pagination_active_bg_color',
			[
				'label' => __( 'Pagination active background color', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#002AFF',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .pivoo-common-paginav .current' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'pagination_hover_color',
			[
				'label' => __( 'Pagination hover text color', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#002AFF',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .pivoo-common-paginav a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'pagination_hover_bg_color',
			[
				'label' => __( 'Pagination hover background color', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#E2E0F5',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .pivoo-common-paginav a:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'pagination_align',
			[
				'label' => __( 'Alignment', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'pivoo' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'pivoo' ),
						'icon' => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'pivoo' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .pivoo-common-paginav' => 'justify-content: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'section_title_typography',
				'label' => __( 'Section Title Typography', 'pivoo' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .pivoo-section-title h3',
			]
		);
		
		$this->add_control(
			'section_title_color',
			[
				'label' => __( 'Section Title Color', 'pivoo' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#402500',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .pivoo-section-title h3' => 'color: {{VALUE}}',
				],
			]
		);
        
        $this->add_control(
			'section-title-gap',
			[
				'label' => __( 'Section Title Bottom Gap', 'pivoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 5,
					],
					
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .pivoo-title-box' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Gird Title Typography', 'plugin-domain' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .pivoo-post.style-seven h4,{{WRAPPER}} .pivoo-post.style-one h3',
			]
		);
		

    $this->end_controls_section();
   }
   
   

   protected function render( $instance = [] ) {

      // get our input from the widget settings.

       $settings = $this->get_settings();
       $grid_layout = $settings['grid_layout'];
       $item_per_page = $settings['item_per_page'];
       $order = $settings['order'];
       $categories = $settings['category'];
       $featured = $settings['featured'];
       $grid_column = $settings['grid_column'];
       $pagination= $settings['pagination'];
       $widget_title = $settings['widget_title'];
       $button_url= $settings['button_url'];
       $button_text= $settings['button_text'];
       $exclude_category=$settings['categorynotin'];
       $widget_sub_title = $settings['widget_sub_title'];
      ?>
      
      <?php 
      
        if (get_query_var('paged')) {
    $paged = get_query_var('paged');
  } elseif (get_query_var('page')) {
    $paged = get_query_var('page');
  } else {
    $paged = 1;
  }
      $args = array(
      'post_type' => 'recipe',
      'paged'               => $paged,
      'posts_per_page' => $item_per_page,
      'order' => (string) trim($order),
      'post_status' => 'publish',
    
    );
    
    if(!empty($categories[0])) {
      $args['tax_query'] = array(
        array(
          'taxonomy' => 'recipe-category',
          'field'    => 'ids',
          'terms'    => $categories
        )
      );
    }
    
      if($featured == 'yes') {
      $args= array(
     'meta_key' => 'pivoo_featured_post',
        'meta_value' => 'on'
      );
    }
    
    if(!empty($exclude_category[0])) {
      $args['tax_query'] = array(
        array(
          'taxonomy' => 'recipe-category',
          'field'    => 'ids',
          'terms'    => $exclude_category,
          'operator' => 'NOT IN'
        )
      );
    }
    
        $the_query = new \WP_Query($args);
        $max_num_pages = $the_query->max_num_pages; 
      ?>


<div id="pivoo-post-regular-grid">
    
    <div class="pivoo-title-box flex items-start justify-between">
    <?php if ($widget_title){?>
    <div class="pivoo-section-title title-style-one">
        <h3><span><?php echo esc_html($widget_title);?></span></h3>
        <?php if ($widget_sub_title){?>
        <p class="pivoo-grid-subt"><?php echo esc_html($widget_sub_title);?></p>
        <?php } ?>
    </div>
    <?php } ?>
        <?php if ($button_url){?>
        <a class="<?php echo esc_url($button_url);?>"><?php echo esc_html($button_text);?> <i class="zil zi-arrow-right"></i></a>
        <?php } ?>
    </div>
         <div class="pivoo-regular-grid  sm:flex -mx-4 flex-wrap">
         <?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
            
            <?php if ($grid_column== 'two'){?>
            <div class="md:w-1/2 md:p-4 p-3 pivoo-post-grid-box">
            <?php } elseif ($grid_column== 'one'){?>
            <div class="w-full md:p-4 p-3 pivoo-post-grid-box">
            <?php } elseif($grid_column== 'three') { ?>
                   <div class="md:w-1/3 md:p-4 p-3 pivoo-post-grid-box">
            <?php } elseif($grid_column== 'five') { ?>
               <div class="md:w-1/5 md:p-4 p-3 pivoo-post-grid-box">
                   
           <?php } elseif($grid_column== 'six') { ?>
               <div class="md:w-1/6 md:p-4 p-3 pivoo-post-grid-box">
            <?php } else {?>
        <div class="md:w-1/4 md:p-4 p-3 pivoo-post-grid-box">
            <?php } ?>
            
            
            
    <?php  switch ($grid_layout) {
    case 'one':
        if ('pivoo_recipe_style_seven'){
         pivoo_recipe_style_seven();
        }
         
         break;
    case 'two':
    
            if ('pivoo_recipe_style_six'){
              pivoo_recipe_style_six();
              
          } 
          
     break;
     
     case 'three':
    
            if ('pivoo_recipe_style_one'){
              pivoo_recipe_style_one();
              
          } 
          
     break;
     
      case 'four':
    
            if ('pivoo_recipe_style_ele_four'){
              pivoo_recipe_style_ele_four();
              
          } 
          
     break;
  } ?>
              
        </div>
              <?php endwhile; wp_reset_postdata(); if($pagination == 'yes') : pivoo_page_paging_nav($max_num_pages); endif; 
              
              ?>
</div>
      
            
        
       
 
</div>



      <?php

   }

   protected function content_template() {}

   public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new pivoo_recipe_grid );
?>