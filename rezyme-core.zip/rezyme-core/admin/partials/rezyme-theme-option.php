<?php

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'rezyme_theme_option';
  
    //
    // Create options
    CSF::createOptions( $prefix, array(
  
      // framework title
      'framework_title'         => 'Rezyme Theme Options <small>by Teconce</small>',
      'framework_class'         => '',
  
      // menu settings
      'menu_title'              => 'Theme Options',
      'menu_slug'               => 'rezyme-options',
      'menu_type'               => 'menu',
      'menu_capability'         => 'manage_options',
      'menu_icon'               => null,
      'menu_position'           => null,
      'menu_hidden'             => false,
      'menu_parent'             => '',
  
      // menu extras
      'show_bar_menu'           => true,
      'show_sub_menu'           => true,
      'show_in_network'         => true,
      'show_in_customizer'      => false,
  
      'show_search'             => true,
      'show_reset_all'          => true,
      'show_reset_section'      => true,
      'show_footer'             => true,
      'show_all_options'        => true,
      'show_form_warning'       => true,
      'sticky_header'           => true,
      'save_defaults'           => true,
      'ajax_save'               => true,
  
      // admin bar menu settings
      'admin_bar_menu_icon'     => '',
      'admin_bar_menu_priority' => 80,
  
      // footer
      'footer_text'             => '',
      'footer_after'            => '',
      'footer_credit'           => '',
  
      // database model
      'database'                => '', // options, transient, theme_mod, network
      'transient_time'          => 0,
  
      // contextual help
      'contextual_help'         => array(),
      'contextual_help_sidebar' => '',
  
      // typography options
      'enqueue_webfont'         => true,
      'async_webfont'           => false,
  
      // others
      'output_css'              => true,
  
      // theme and wrapper classname
      'nav'                     => 'normal',
      'theme'                   => 'dark',
      'class'                   => '',
  
      // external default values
      'defaults'                => array(),
  
    ) );
  
    //
    // Create a section
    CSF::createSection( $prefix, array(
      'title'  => 'Header Settings',
      'fields' => array(
  
        // Site Logo Field
          array(
            'id'      => 'site-logo',
            'type'    => 'media',
            'title'   => 'Add Site Logo',
            'library' => 'image',
          ),
          array(
            'id'      => 'site-banner',
            'type'    => 'media',
            'title'   => 'Add Site Banner',
            'library' => 'image',
          ),
  
      )
    ) );

    // Create a section
    CSF::createSection( $prefix, array(
        'title'  => 'Typographi',
        'fields' => array(
    
          // Site Logo Field
            array(
              'id'      => 'site-loo',
              'type'    => 'media',
              'title'   => 'Add Site Logo',
              'library' => 'image',
            ),
    
        )
      ) );
  

  
  }