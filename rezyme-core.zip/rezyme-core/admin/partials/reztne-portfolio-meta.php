<?php 


// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'rezyme_portfolio_meta';
  
    //
    // Create a metabox
    CSF::createMetabox( $prefix, array(
      'title'              => 'Portfolio Gallery Images',
      'post_type'          => 'portfolio',
      'data_type'          => 'serialize',
      'context'            => 'side',
      'priority'           => 'default',
      'exclude_post_types' => array(),
      'page_templates'     => '',
      'post_formats'       => '',
      'show_restore'       => false,
      'enqueue_webfont'    => true,
      'async_webfont'      => false,
      'output_css'         => true,
      'nav'                => 'normal',
      'theme'              => 'dark',
      'class'              => '',
    ) );
  
    //
    // Create a section
    CSF::createSection( $prefix, array(
      'title'  => '',
      'fields' => array(
  
        //
        // A text field
        array(
            'id'    => 'portfolio-gallery',
            'type'  => 'gallery',
            'title' => 'Gallery Images',
          ),
  
      )
    ) );
  
  
  }









?>