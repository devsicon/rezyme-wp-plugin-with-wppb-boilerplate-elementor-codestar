<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed direct

class rezyme_portfolio extends Widget_Base {

	public function get_name() {
		return 'rezyme-portfolio';
	}

	public function get_title() {
		return __( 'Rezyme Portfolio', 'rezyme-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'rezyme-category' ];
	}


    protected function _register_controls() {

		$this->start_controls_section(
			'portfolio_section',
			[
				'label' => __( 'Content', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'portfolio_title',
			[
				'label' => __( 'Portfolio Title', 'rezyme-coren' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Portfolio title here', 'rezyme-core' ),
                'label_block' => true,
			]
		);
		$this->add_control(
            'order',
            [
                'label' => __( 'Order', 'rezyme-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending'
                ],
                'default' => 'desc',

            ]
        );
        $this->add_control(
			'item_per_page',
			[
				'label' => __( 'Amount of item to display', 'rezyme-core' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 4,
				'max' => 100,
				'step' => 1,
				'default' => 20,
			]
		);
        
		$this->end_controls_section();

	}

    protected function render( $instance = [] ) {
        $portfolio = $this->get_settings_for_display();

        $item_per_page = $portfolio['item_per_page'];
        $order = $portfolio['order'];

        $args = array(  
            'post_type' => 'portfolio',
            'post_status' => 'publish',
            'posts_per_page' => $item_per_page,
            'order' => (string) trim($order),
        );
    
        $p_query = new \WP_Query( $args ); 

        // Get Post Taxonomies
        $taxonomies = get_object_taxonomies( array( 'post_type' => 'portfolio' ) );
        $portfolio_categories = [];
        
        foreach( $taxonomies as $taxonomy ) {
            $terms = get_terms( $taxonomy );
            foreach( $terms as $term ){
                if(!in_array($term, $portfolio_categories)){
                   array_push($portfolio_categories, $term );
                }
            }
        }
        // echo '<pre>';
        // print_r($portfolio_categories);
        // echo '</pre>';

        ?>
            <section class="col-md-9 col-sm-12 col-xs-12 col-md-offset-3 rzm_portfolio" id="portfolio">
                <h1 class="title"><?php echo $portfolio['portfolio_title']; ?></h1>
                <section class="filter-section">
                        <div class="row">
                            <div class="col-sm-12 col-xs-12">

                            
                                <div class="filter-container isotopeFilters3">
                                    <ul class="list-inline filter">
                                        <li class="active"><a href="#" data-filter="*">All </a></li>
                                        <?php 
                                        foreach($portfolio_categories as $portfolio_menu_item){ 
                                            if($portfolio_menu_item->slug !== 'uncategorized' && $portfolio_menu_item->count > 0 ){
                                            ?>
                                            <li class=""><a href="#" data-filter=".<?php echo strtolower($portfolio_menu_item->name); ?>"><?php echo strtoupper($portfolio_menu_item->name); ?></a></li>
                                        <?php } } ?>                                        
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                    
                </section>
                <section class="portfolio-section port-col">
                        <div class="row">
                            <div class="isotopeContainer3" style="position: relative;">

                            <?php while ( $p_query->have_posts() ) : $p_query->the_post(); ?>
                            <div class="col-sm-6 isotopeSelector <?php foreach ( get_the_terms( get_the_ID(), 'category' ) as $tax ) { echo strtolower($tax->name) . ' '; } ?>">
                                                    
                                <article class="">
                                    <figure>
                                    <?php the_post_thumbnail(); ?>
                                        <div class="overlay-background">
                                            <div class="inner"></div>
                                        </div>
                                        <div class="overlay">
                                            <div class="inner-overlay">
                                                <div class="inner-overlay-content with-icons">
                                                <?php 
                                                    $portfoliometa = get_post_meta( get_the_ID(), 'rezyme_portfolio_meta', true );                                                   
                                                    $gallery_ids = explode( ',', $portfoliometa['portfolio-gallery'] ); 
                                                    if ( ! empty( $gallery_ids ) ) {
                                                    foreach ( $gallery_ids as $hi=>$gallery_item_id ) {                                                  
                                                        ?>
                                                        <a title="First Image" class="fancybox-pop" <?php if($hi !== 0):?> style="display: none" <?php endif; ?> rel="portfolio-<?php echo get_the_ID(); ?>" href="<?php echo wp_get_attachment_url( $gallery_item_id ); ?>"><?php if($hi === 0):?><i class="fa fa-plus-circle"></i><?php endif; ?></a>
                                                        <?php
                                                    }
                                                    }                            
                                                ?>
                                                   
                                                </div>
                                            </div>
                                        </div>
                                    </figure>
                                    
                                </article>
                            </div>

                            <?php  endwhile; wp_reset_postdata(); ?>
                            
                            </div>
                        </div>
                </section>
                <div class="rzm_button">
                        <a href="" class="btn btn-sm btn-default">Show More</a>
                </div>
            </section>


        <?php


    }


    protected function _content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rezyme_portfolio);