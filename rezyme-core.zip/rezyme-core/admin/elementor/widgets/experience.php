<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed direct

class rezyme_experience extends Widget_Base {

	public function get_name() {
		return 'rezyme-experience';
	}

	public function get_title() {
		return __( 'Rezyme Experience', 'rezyme-core' );
	}

	public function get_icon() {
		return 'eicon-kit-details';
	}

	public function get_categories() {
		return [ 'rezyme-category' ];
	}

    protected function _register_controls() {

        $this->start_controls_section(
			'experience_section',
			[
				'label' => __( 'Content', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'timeline_title',
			[
				'label' => __( 'Timeline Title', 'rezyme-coren' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Timeline title here', 'rezyme-core' ),
                'label_block' => true,
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
			'Job_duration',
			[
				'label' => __( 'Duration', 'rezyme-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Mar 2020 - Present', 'rezyme-core' ),
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'company_name',
			[
				'label' => __( 'Company Name', 'rezyme-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'GraphicPen', 'rezyme-core' ),
                'label_block' => true,
			]
		);
        $repeater->add_control(
			'job_position',
			[
				'label' => __( 'Designation', 'rezyme-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'CEO', 'rezyme-core' ),
                'label_block' => true,
			]
		);


        $this->add_control(
			'experiences',
			[
				'label' => __( 'Title', 'rezyme-core' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'Job_duration' => __( 'Mar 2020 - Present', 'rezyme-core' ),
                        'company_name' => __( 'GraphicPen', 'rezyme-core' ),
                        'job_position' => __( 'CEO', 'rezyme-core' ),
						
					],					
				],
				'title_field' => '{{{ Job_duration }}}',
			]
		);
        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
			'job_duration_control',
			[
				'label' => __( 'Duration', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
            'job_duration_color',
            [
                'label' => __( 'Color', 'rezyme-core' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Core\Schemes\Color::get_type(),
                    'value' => Core\Schemes\Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} #rzm_timeline .rzm_timeline-movement .rzm_timeline-item .rzm_timeline-panel.credits .rzm_timeline-panel-ul li' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'job_duration_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} #rzm_timeline .rzm_timeline-movement .rzm_timeline-item .rzm_timeline-panel.credits .rzm_timeline-panel-ul li',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'job_company_control',
			[
				'label' => __( 'Company Name', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
            'company_name_color',
            [
                'label' => __( 'Color', 'rezyme-core' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Core\Schemes\Color::get_type(),
                    'value' => Core\Schemes\Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .active li .rzm_importo' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'job_company_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .active li .rzm_importo',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'job_designation_control',
			[
				'label' => __( 'Designation', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
            'job_designation_color',
            [
                'label' => __( 'Color', 'rezyme-core' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Core\Schemes\Color::get_type(),
                    'value' => Core\Schemes\Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .rzm_causale' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'job_designation_typography',
				'label' => __( 'Typography', 'plugin-domain' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .rzm_causale',
			]
		);

        $this->end_controls_section();
    }



    protected function render( $instance = [] ){
    $settings = $this->get_settings_for_display(); ?>
<section class="col-md-9 col-sm-12 col-xs-12 col-md-offset-3 rzm_experience" id="experience">
      <h1 class="title"><?php echo $settings['timeline_title']; ?></h1>
    <div id="rzm_timeline">
    <?php foreach( $settings['experiences'] as $ak=>$item ){ ?>
            <div class="row rzm_timeline-movement">
                    
                <div class="rzm_timeline-badge <?php if( $ak === 0):?>active_box<?php endif; ?>">    
                </div>

                <div class="col-sm-6 col-xs-12 rzm_timeline-item">
                    <div class="row">
                        <div class="col-sm-11 col-xs-12">
                            <div class="rzm_timeline-panel credits">
                                <ul class="rzm_timeline-panel-ul">
                                    <li><?php echo $item['Job_duration']; ?></li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xs-12  rzm_timeline-item">
                    <div class="row">
                        <div class="col-sm-offset-1 col-sm-11 col-xs-12">
                            <div class="rzm_timeline-panel debits">
                                <ul class="rzm_timeline-panel-ul active">
                                    <li><span class="<?php if( $ak === 0):?>rzm_importo<?php endif; ?>"><?php echo $item['company_name']; ?></span></li>
                                    <li><span class="rzm_causale"><?php echo $item['job_position']; ?> </span> </li>
                                    
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        
        <?php } ?>
    </div>
    </section>
        <?php
		

	}

    protected function _content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rezyme_experience);


