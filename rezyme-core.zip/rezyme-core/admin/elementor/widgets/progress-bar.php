<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed direct

class rezyme_progressbar extends Widget_Base {

	public function get_name() {
		return 'rezyme-progressbar';
	}

	public function get_title() {
		return __( 'Rezyme Progressbar', 'rezyme-core' );
	}

	public function get_icon() {
		return 'eicon-skill-bar';
	}

	public function get_categories() {
		return [ 'rezyme-category' ];
	}


    protected function _register_controls() {

		$this->start_controls_section(
			'progressbar_content_section',
			[
				'label' => __( 'Progress Bar', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
        
        $repeater = new Repeater();

		$repeater->add_control(
			'list_title', [
				'label' => __( 'Title', 'rezyme-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'List Title' , 'rezyme-core' ),
				'label_block' => true,
			]
		);
        $repeater->add_control(
			'progress',
			[
				'label' => __( 'Percentage', 'plugin-domain' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [  '%' ],
				'range' => [
					
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				
			]
		);

		$this->add_control(
			'list',
			[
				'label' => __( 'Title', 'rezyme-core' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => __( 'My Skills', 'rezyme-core' ),
                        'progress' => __( '50', 'rezyme-core' ),
						
					],					
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

		$this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
			'progressbar_style_section',
			[
				'label' => __( 'Progress Bar', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'bar_color',
			[
				'label' => __( 'Color', 'rezyme-core' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Core\Schemes\Color::get_type(),
					'value' => Core\Schemes\Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .progress' => 'background: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'bar_bg_color',
			[
				'label' => __( 'Background Color', 'rezyme-core' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Core\Schemes\Color::get_type(),
					'value' => Core\Schemes\Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .rzm_progress_bar .progress-bar' => 'background: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'height',
			[
				'label' => __( 'Bar Height', 'rezyme-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors' => [
					'{{WRAPPER}} .rzm_progress_bar .progress' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'progresstitle_style_section',
			[
				'label' => __( 'Title Style', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'progress_title_color',
			[
				'label' => __( 'Color', 'rezyme-core' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Core\Schemes\Color::get_type(),
					'value' => Core\Schemes\Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .rzm_progress_bar h4' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Typography', 'rezyme-core' ),
				'scheme' => Core\Schemes\Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .rzm_progress_bar h4',
			]
		);

        $this->end_controls_section();

	}


   protected function render( $instance = [] ){
    $settings = $this->get_settings_for_display(); ?>
	<section class="col-md-9 col-sm-12 col-xs-12 col-md-offset-3 first profile rez_about">

    <?php 
	foreach( $settings['list'] as $item ){ ?>

        <div class="rzm_progress_bar">
            <h4><?php echo $item['list_title']; ?></h4>
            <small class="pull-right rzm_perchantage"><?php echo $item['progress']['size']; ?><?php echo $item['progress']['unit']; ?></small>
            <div class="progress">
                  <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $item['progress']['size']; ?>" aria-valuemin="0" aria-valuemax="<?php echo $item['progress']['size']; ?>" style="width: <?php echo $item['progress']['size']; ?><?php echo $item['progress']['unit']; ?>;">
                    <span class="sr-only">90% Complete</span>
                  </div>
            </div>
        </div>

        <?php } ?>
	<div class="clear"></div>
	</section>

	<?php }

    protected function _content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rezyme_progressbar);

