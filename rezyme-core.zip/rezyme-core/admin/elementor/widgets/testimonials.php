<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed direct

class rezyme_testimonials extends Widget_Base {

	public function get_name() {
		return 'rezyme-testimonials';
	}

	public function get_title() {
		return __( 'Rezyme Testimonials', 'rezyme-core' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	public function get_categories() {
		return [ 'rezyme-category' ];
	}



    protected function _register_controls() {

		$this->start_controls_section(
			'testimonials_section',
			[
				'label' => __( 'Testimonial', 'rezyme-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'testimonial_title',
			[
				'label' => __( 'Testimonials Title', 'rezyme-coren' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Portfolio title here', 'rezyme-core' ),
                'label_block' => true,
			]
		);

        $repeater = new Repeater();

		$repeater->add_control(
			'client_comment',
			[
				'label' => __( 'Comment', 'rezyme-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => __( 'Type your comment here', 'rezyme-core' ),
			]
		);

        $repeater->add_control(
			'client_image',
			[
				'label' => __( 'Choose Image', 'rezyme-core' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);


        $repeater->add_control(
			'client_name',
			[
				'label' => __( 'Name', 'rezyme-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Daniel Ray', 'rezyme-core' ),
                'label_block' => true,
			]
		);

        $repeater->add_control(
			'client_title',
			[
				'label' => __( 'Title', 'rezyme-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'CEO, GravityPayments', 'rezyme-core' ),
                'label_block' => true,
			]
		);

        $this->add_control(
			'testimoniasl',
			[
				'label' => __( 'Client Testimonial', 'rezyme-core' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'client_comment' => __( 'Client Comment', 'rezyme-core' ),
                        'client_image' => __( 'Client Image', 'rezyme-core' ),
                        'client_name' => __( 'Client Name', 'rezyme-core' ),
                        'client_title' => __( 'Client Title', 'rezyme-core' ),
					],
					
				],
				'title_field' => '{{{ client_name }}}',
			]
		);

		$this->end_controls_section();

	}

    protected function render() {

		$testimonials = $this->get_settings_for_display();
        $testimoniasl_lenght = $testimonials['testimoniasl']
        
        ?>

<section class="col-md-9 col-sm-12 col-xs-12 col-md-offset-3 rzm_Testimonial" id="testimonial">
    <h1 class="title"><?php echo $testimonials['testimonial_title']; ?></h1>
    <div class="rzm_testimonial_content">
            <div id="carousel" class="carousel slide" data-ride="carousel"> <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php  for ($ti = 0; $ti < count($testimoniasl_lenght); $ti++): ?>
                    <li data-target="#carousel" data-slide-to="<?php echo $ti; ?>" class="<?php if($ti === 0): ?>active<?php endif; ?>"></li>
                <?php endfor; ?> 
            </ol>
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
            <?php foreach( $testimonials['testimoniasl'] as $i=>$testimonial ){ ?>
                <div class="item <?php if($i === 0): ?>active<?php endif; ?>">
                <div class="row">
                    <div class="col-xs-12">
                    <div class="thumbnail adjust1">
                    <div class="col-md-2 col-sm-2 col-xs-12"> <img class="media-object img-rounded img-responsive img-circle" src="<?php echo $testimonial['client_image']['url']; ?>" alt=""> </div>
                        <div class="col-md-10 col-sm-10 col-xs-12">
                        <div class="caption">
                        <p><?php echo $testimonial['client_comment']; ?></p>
                        <blockquote class="adjust2">
                            <p><?php echo $testimonial['client_name']; ?></p>
                            <small><?php echo $testimonial['client_title']; ?></small> </blockquote>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>  
            <?php } ?>
            </div>
            
        </div>
    </div>
</section>

		
    <?php
	}


    protected function _content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new rezyme_testimonials);