<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
define( 'REZYME_ELEMENTOR_URL', plugins_url( '/', __FILE__ ) );
define( 'REZYME_ELEMENTOR_PATH', plugin_dir_path( __FILE__ ) );
define( 'REZYME_ELEMENTOR_ROOT_URL', plugins_url( __FILE__ ) );
define( 'REZYME_ELEMENTOR_PL_ROOT_URL', plugin_dir_url(  __FILE__ ) );
define( 'REZYME_TEMPLATES_FOR_ELEMENTOR_VERSION', '2.9' );



function rezyme_elementor_widget_categorie( $elements_manager ) {

	$elements_manager->add_category(
		'rezyme-category',
		[
			'title' => __( 'Rezyme Elements', 'rezyme-core' ),
			'icon' => 'fa fa-plug',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'rezyme_elementor_widget_categorie' );


function rezyme_elementor_elements(){
    require_once REZYME_ELEMENTOR_PATH.'widgets/progress-bar.php';
    require_once REZYME_ELEMENTOR_PATH.'widgets/experience.php';
	require_once REZYME_ELEMENTOR_PATH.'widgets/testimonials.php';
	require_once REZYME_ELEMENTOR_PATH.'widgets/portfolio.php';
}
add_action('elementor/widgets/widgets_registered','rezyme_elementor_elements');


